﻿using System;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.Activities.Expressions;
using System.Collections.Generic;
using JR.Utils.GUI.Forms;

namespace NETRESTAPI
{
    public partial class Form1 : Form
    {
        FlexibleMessageBox box = new FlexibleMessageBox();
        RootObject ro = new RootObject();
        jsonSpiecies jp = new jsonSpiecies();

        public Form1()
        {

            InitializeComponent();

            // creating city link------------------------
            string token = "?token=9bb4facb6d23f48efbf424bb05c0c1ef1cf6f468393bc745d42179ac4aca5fee";
            string citylink = "http://apiv3.iucnredlist.org/api/v3/country/list";
            string cityUrl = citylink + token;
            //-------------------------------------------


            // creating rest class object, giving link and getting response
            RestClient rClient = new RestClient();
            rClient.endPoint = cityUrl;

            string cityResponseData = string.Empty;
            cityResponseData = rClient.makeRequest();
            //debugOutput(cityResponseData);
            //-------------------------------------------------

            //deserializing JSON data using newtownsoft.json

            deserialiseJSON(cityResponseData);

        }
        #region deserialisenCountry
        private void deserialiseJSON(string strJSON)
        {

            try
            {
                ro = JsonConvert.DeserializeObject<RootObject>(strJSON);


                //Adding all data of citys to listview
                foreach (Result r in ro.results)
                {
                    string cityIsocode = r.isocode;
                    string cityName = r.country;
                    ListViewItem citydata = new ListViewItem(cityIsocode, 0);
                    citydata.SubItems.Add(cityName);
                    cityList.Items.Add(citydata);
                }

            }
            catch (Exception ex)
            {
                debugOutput("houston we have a problem");

            }
        }


        private string deserialiseJSONSpiecies(string strJSON)
        {
            string list = "";

            try
            {
                jp = JsonConvert.DeserializeObject<jsonSpiecies>(strJSON);
                debugOutput(jp.count.ToString());
                for (int i = 0; i < jp.count; i++)
                {

                    string spieciesName = jp.result[i].scientific_name;
                    list = list + spieciesName.ToString() + "\n";

                }




            }
            catch (Exception ex)
            {
                debugOutput("houston we have a problem");

            }
            return list;
        }
        #endregion

        #region Debugers
        private void debugOutput(string strDebugText)
        {
            try
            {
                System.Diagnostics.Debug.Write(strDebugText + Environment.NewLine);
                txtResponse.Text = txtResponse.Text + strDebugText + Environment.NewLine;
                txtResponse.SelectionStart = txtResponse.TextLength;
                txtResponse.ScrollToCaret();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Write(ex.Message, ToString() + Environment.NewLine);
            }
        }
        #endregion

        #region update list
        public void resetListOfData()
        {
            cityList.Items.Clear();
            foreach (Result r in ro.results)
            {
                string cityIsocode = r.isocode;
                string cityName = r.country;
                ListViewItem citydata = new ListViewItem(cityIsocode, 0);
                citydata.SubItems.Add(cityName);
                cityList.Items.Add(citydata);
            }

        }
        #endregion

        #region UI Event Hanglers
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
      

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void cityList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        #endregion

        #region AUD
        private void button4_Click(object sender, EventArgs e)
        {
            int kintamasis = 0;
            try 
            {

                string selectedId = cityList.SelectedItems[0].Index.ToString();
                string selectedIsocode = cityList.SelectedItems[0].SubItems[0].Text;
                string selectedcityName = cityList.SelectedItems[0].SubItems[1].Text;

                for (int i = 0; i < ro.results.Count; i++)
                 {
                    Result r = ro.results[i];
                    string cityIsocode = r.isocode;

                    if (cityIsocode.ToString() == selectedIsocode.ToString())
                    {
                        kintamasis = i;
                        break;
                    }
                }


                string isocode = "";
                string cityNewName = "";

                isocode = Microsoft.VisualBasic.Interaction.InputBox("Right now value " + ro.results[kintamasis].isocode, "Updating isocode of country " + ro.results[kintamasis].isocode , ro.results[kintamasis].isocode);
                cityNewName = Microsoft.VisualBasic.Interaction.InputBox("Right now value " + ro.results[kintamasis].country, "Updating name of the country " + ro.results[kintamasis].country, ro.results[kintamasis].country);

                isocode = isocode.Trim();
                cityNewName = cityNewName.Trim();

                if ( isocode != "")
                {
                    ro.results[kintamasis].isocode = isocode;
                }

                if (cityNewName.ToString() != "")
                {
                    debugOutput(cityNewName.ToString() + "  "+ ro.results[kintamasis].country.ToString());
                    ro.results[kintamasis].country = cityNewName;
                }
              
                if (isocode != null & cityNewName != null)
                {
                    resetListOfData();
                }

               
                
            }
            catch
            {
                MessageBox.Show("Select any city to update it ", "Nothing Selected", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
 
        }

        private void button3_Click(object sender, EventArgs e)
        {
            {
                int kintamasis = 0;
                try
                {

                    string selectedId = cityList.SelectedItems[0].Index.ToString();
                    string selectedIsocode = cityList.SelectedItems[0].SubItems[0].Text;
                    selectedIsocode = selectedIsocode.Trim();
                    string selectedcityName = cityList.SelectedItems[0].SubItems[1].Text;

                    for (int i = 0; i < ro.results.Count; i++)
                    {
                        Result r = ro.results[i];
                        string cityIsocode = r.isocode;

                        if (cityIsocode.ToString() == selectedIsocode.ToString())
                        {
                            kintamasis = i;
                            break;
                        }
                    }

                    DialogResult result = MessageBox.Show("Are you really want to dellet it ", "Nothing Selected", MessageBoxButtons.YesNoCancel);

                    if (result == DialogResult.Yes)
                    {
                        ro.results.RemoveAt(kintamasis);
                        resetListOfData();
                    }
                }
                catch
                {
                    MessageBox.Show("Select any city to update it ", "Nothing Selected", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int kintamasis = 0;
            try
            {
                string isocode = "";
                string cityNewName = "";

                isocode = Microsoft.VisualBasic.Interaction.InputBox("Enter new Country Isocode " , "Adding new country ", "");
                isocode = isocode.Trim();

                if (isocode != "")
                {
                    ro.results[kintamasis].isocode = isocode;

                    cityNewName = Microsoft.VisualBasic.Interaction.InputBox("Enter new Country name " , "Adding new country" , "");

                    if (cityNewName.ToString() != "")
                    {
                        debugOutput(cityNewName.ToString() + "  " + ro.results[kintamasis].country.ToString());
                        ro.results[kintamasis].country = cityNewName;
                    }
                }

                if (isocode != null & cityNewName != null)
                {
                    resetListOfData();
                }
            }
            catch
            {
                
            }
           

        }
        #endregion

        #region Animal list
        private void button1_Click_1(object sender, EventArgs e)
        {
             string token = "?token=9bb4facb6d23f48efbf424bb05c0c1ef1cf6f468393bc745d42179ac4aca5fee";
             string citylink = "http://apiv3.iucnredlist.org/api/v3/country/getspecies/";

             try
             {

                 string selectedIsocode = cityList.SelectedItems[0].SubItems[0].Text;
                Console.WriteLine(selectedIsocode);
                 string linkToSpiecies = citylink + selectedIsocode + token;
                Console.WriteLine(linkToSpiecies);

                RestClient rClientSpiecies = new RestClient();
                 rClientSpiecies.endPoint = linkToSpiecies;

                 string citySpieciesCountry = string.Empty;
                 citySpieciesCountry = rClientSpiecies.makeRequest();

                string list = deserialiseJSONSpiecies(citySpieciesCountry);

                try
                 {
                    if(list != string.Empty)
                    FlexibleMessageBox.Show(list);
                    else
                    {
                        MessageBox.Show("List is empty", "List of spiecies", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                  
                   


                 }
                 catch (Exception ex)
                 {
                    MessageBox.Show("List is empty", "List of spiecies", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }

             }
             catch
             {
                 MessageBox.Show("Select any city to check it spiecies list ", "Nothing Selected", MessageBoxButtons.OK, MessageBoxIcon.Error);
             } 
        }
#endregion
    }
}
