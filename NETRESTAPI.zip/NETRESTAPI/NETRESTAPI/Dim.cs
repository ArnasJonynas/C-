﻿namespace NETRESTAPI
{
    internal class Dim
    {
    }
}