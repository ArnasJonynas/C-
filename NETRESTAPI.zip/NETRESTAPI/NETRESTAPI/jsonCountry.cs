﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace NETRESTAPI
{
    public class RootObject
    {
        public int count { get; set; }
        public List <Result> results { get; set; }
    }

    public class Result
    {
        public String isocode { get; set; }
        public String country { get; set; }
    }
}
