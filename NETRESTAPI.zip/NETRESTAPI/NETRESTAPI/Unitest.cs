﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NETRESTAPI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//ctrl r / t

namespace NETRESTAPI.Tests
{
    [TestClass()]
    public class Unitest
    {
        private object cityList;

        [TestMethod()]
        public void Htppresponse()
        {
            string link = "https://stackify.com/unit-testing-basics-best-practices/";
            RestClient rClient = new RestClient();
            rClient.endPoint = link;

            string cityResponseData = null;
            cityResponseData = rClient.makeRequest();

            Assert.IsNotNull(cityResponseData);
        }

        [TestMethod()]
        public void CreatingItemsToList()
        {
            ListViewItem citydata = new ListViewItem("Veikia", 0);
            citydata.SubItems.Add("veikia");

            Assert.IsNotNull(citydata);
        }
        [TestMethod()]
        public void AddingItemsToList()
        {
            Form1 f1 = new Form1();
            f1.Show();
            f1.Close();
        }

    }
}