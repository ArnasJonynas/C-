﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NETRESTAPI
{
    public class jsonSpiecies
    {
        public int count { get; set; }
        public string country { get; set; }
        public List<ResultSpiecies> result { get; set; }
    }

    public class ResultSpiecies
    {
        public String taxonid { get; set; }
        public String scientific_name { get; set; }
        public String subspecies { get; set; }
        public String rank { get; set; }
        public String subpopulation { get; set; }
        public String category { get; set; }

    }
}

