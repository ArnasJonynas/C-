﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NETRESTAPI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NETRESTAPI.Tests
{
    [TestClass()]
    public class Form1Tests
    {
        [TestMethod()]
        public void Htppresponse()
        {
            string link = "https://stackify.com/unit-testing-basics-best-practices/";
            RestClient rClient = new RestClient();
            rClient.endPoint = cityUrl;

            string cityResponseData = string.Empty;
            cityResponseData = rClient.makeRequest();
        }

    }
}